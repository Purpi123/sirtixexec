1. Go into "Data"
2. Run "Sirtix.exe"

2024 Sirtix